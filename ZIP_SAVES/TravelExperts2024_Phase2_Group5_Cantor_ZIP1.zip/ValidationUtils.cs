/*
Author :: η℩.cαηtor ↈ
Co-Author :: ⌈𝗆𝖾𝗍𝖺𝖼𝗈𝖽𝖺⌋ ⊛


File :: ValidationUtils, Version 2
*/

public static class ValidationUtils
{
    /*
    Method: IsNull
    Purpose: Checks if a given reference type value is null.

    Parameters:
    - T value: The reference type value to validate.

    Returns:
    - bool: True if the value is null; otherwise, false.
    */
    public static bool IsNull<T>(T value) where T : class => value == null;

    /*
    Method: IsNotNullOrDefault
    Purpose: Checks if a value is not null and is not the default value.

    Parameters:
    - T value: The value to validate.

    Returns:
    - bool: True if the value is neither null nor default; otherwise, false.
    */
    public static bool IsNotNullOrDefault<T>(T value) => value != null && !EqualityComparer<T>.Default.Equals(value, default);

    /*
    Method: IsEmpty
    Purpose: Checks if a given value is empty (applicable to strings and collections).

    Parameters:
    - T value: The value to validate.

    Returns:
    - bool: True if the value is empty; otherwise, false.

    Throws:
    - ArgumentException: If the type is unsupported for emptiness check.
    */
    public static bool IsEmpty<T>(T value) =>
        value is string str ? string.IsNullOrEmpty(str) :
        value is ICollection collection ? collection.Count == 0 :
        throw new ArgumentException("Unsupported type for IsEmpty check.");

    /*
    Method: IsNullOrEmpty
    Purpose: Checks if a given value is either null or empty.

    Parameters:
    - T value: The value to validate.

    Returns:
    - bool: True if the value is null or empty; otherwise, false.
    */
    public static bool IsNullOrEmpty<T>(T value) => IsNull(value) || IsEmpty(value);

    /*
    Method: MatchesPattern
    Purpose: Checks if a string matches a specified regular expression pattern.

    Parameters:
    - string input: The string to validate.
    - string pattern: The regex pattern to match against.

    Returns:
    - bool: True if the input matches the pattern; otherwise, false.
    */
    public static bool MatchesPattern(string input, string pattern) => !string.IsNullOrEmpty(input) && Regex.IsMatch(input, pattern);

    /*
    Method: IsAtMin
    Purpose: Checks if a value is at or above a specified minimum.

    Parameters:
    - T value: The value to validate.
    - T min: The minimum threshold.

    Constraints:
    - T must implement IComparable<T>.

    Returns:
    - bool: True if the value meets the minimum; otherwise, false.
    */
    public static bool IsAtMin<T>(T value, T min) where T : IComparable<T> => value.CompareTo(min) >= 0;

    /*
    Method: IsAtMax
    Purpose: Checks if a value is at or below a specified maximum.

    Parameters:
    - T value: The value to validate.
    - T max: The maximum threshold.

    Constraints:
    - T must implement IComparable<T>.

    Returns:
    - bool: True if the value meets the maximum; otherwise, false.
    */
    public static bool IsAtMax<T>(T value, T max) where T : IComparable<T> => value.CompareTo(max) <= 0;

    /*
    Method: IsWithinRange
    Purpose: Checks if a value is within a specified range.

    Parameters:
    - T value: The value to validate.
    - T min: The minimum acceptable value.
    - T max: The maximum acceptable value.

    Returns:
    - bool: True if the value is within the range; otherwise, false.
    */
    public static bool IsWithinRange<T>(T value, T min, T max) where T : IComparable<T> => IsAtMin(value, min) && IsAtMax(value, max);

    /*
    Method: IsInRange
    Purpose: Alias for IsWithinRange; checks if a value is within a specified range.

    Parameters:
    - T value: The value to validate.
    - T min: The minimum acceptable value.
    - T max: The maximum acceptable value.

    Returns:
    - bool: True if the value is within the range; otherwise, false.
    */
    public static bool IsInRange<T>(T value, T min, T max) where T : IComparable<T> => IsWithinRange(value, min, max);

    /*
    Method: AllElementsMatch
    Purpose: Validates that all elements in a collection satisfy a specified condition.

    Parameters:
    - IEnumerable<T> collection: The collection to check.
    - Func<T, bool> predicate: The condition each element must satisfy.

    Returns:
    - bool: True if all elements meet the condition; otherwise, false.
    */
    public static bool AllElementsMatch<T>(IEnumerable<T> collection, Func<T, bool> predicate) => collection != null && collection.All(predicate);

    /*
    Method: ValidateIf
    Purpose: Conditionally validates a value based on a specified condition and validation rule.

    Parameters:
    - T value: The value to validate.
    - Func<T, bool> condition: The condition under which validation occurs.
    - Func<T, bool> validationRule: The rule to validate the value if the condition is met.

    Returns:
    - bool: True if the condition is not met or if the validation rule is satisfied; otherwise, false.
    */
    public static bool ValidateIf<T>(T value, Func<T, bool> condition, Func<T, bool> validationRule) => !condition(value) || validationRule(value);

    /*
    Method: ValidateAll
    Purpose: Checks if a value meets all specified validation rules.

    Parameters:
    - T value: The value to validate.
    - params Func<T, bool>[] validationRules: The validation rules to apply.

    Returns:
    - bool: True if all rules are met; otherwise, false.
    */
    public static bool ValidateAll<T>(T value, params Func<T, bool>[] validationRules) => validationRules.All(rule => rule(value));

    /*
    Method: ValidateAsync
    Purpose: Asynchronously validates a value using an async validation rule.

    Parameters:
    - T value: The value to validate.
    - Func<T, Task<bool>> asyncValidationRule: The asynchronous validation rule.

    Returns:
    - Task<bool>: True if validation succeeds; otherwise, false.
    */
    public static async Task<bool> ValidateAsync<T>(T value, Func<T, Task<bool>> asyncValidationRule) => await asyncValidationRule(value);

    /*
    Method: IsLengthInRange
    Purpose: Checks if the length of a string is within a specified range.

    Parameters:
    - string value: The string to validate.
    - int minLength: The minimum length.
    - int maxLength: The maximum length.

    Returns:
    - bool: True if the length is within the range; otherwise, false.
    */
    public static bool IsLengthInRange(string value, int minLength, int maxLength) => value != null && value.Length >= minLength && value.Length <= maxLength;

    /*
    Method: ValidateWithMessage
    Purpose: Validates a value using a specified rule and outputs a custom error message if validation fails.

    Parameters:
    - T value: The value to validate.
    - Func<T, bool> validationRule: The rule to validate the value.
    - out string errorMessage: Outputs a custom message if validation fails.
    - string customMessage: The custom error message to use if validation fails.

    Returns:
    - bool: True if validation passes; otherwise, false, with an error message.
    */
    public static bool ValidateWithMessage<T>(T value, Func<T, bool> validationRule, out string errorMessage, string customMessage = "Validation failed.")
    {
        if (!validationRule(value))
        {
            errorMessage = customMessage;
            return false;
        }
        errorMessage = string.Empty;
        return true;
    }

    /*
    Method: IsValidEnumValue
    Purpose: Checks if a value is a defined member of an enum.

    Parameters:
    - TEnum value: The enum value to check.

    Returns:
    - bool: True if the value is a valid enum member; otherwise, false.
    */
    public static bool IsValidEnumValue<TEnum>(TEnum value) where TEnum : struct, Enum => Enum.IsDefined(typeof(TEnum), value);

    /*
    Method: DisplayError
    Purpose: Displays an error message in a message box, with optional logging.

    Parameters:
    - Exception ex: The exception to log and display.
    - string customMessage: A custom message to display along with the error.
    - bool logError: Indicates if the error should be logged to the console.

    Returns:
    - void
    */
    public static void DisplayError(Exception ex, string customMessage = "An error occurred.", bool logError = true)
    {
        if (logError) LogError(ex);
        MessageBox.Show($"{customMessage}\nError Type: {ex.GetType()}\nMessage: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }

    /*
    Method: DisplayMessage
    Purpose: Shows a message box with a custom message and icon.

    Parameters:
    - string message: The message to display.
    - string title: The title of the message box.
    - MessageBoxIcon icon: The icon to display.

    Returns:
    - void
    */
    public static void DisplayMessage(string message, string title = "Information", MessageBoxIcon icon = MessageBoxIcon.Information) =>
        MessageBox.Show(message, title, MessageBoxButtons.OK, icon);

    /*
    Method: LogError
    Purpose: Logs the exception details to the console.

    Parameters:
    - Exception ex: The exception to log.

    Returns:
    - void
    */
    private static void LogError(Exception ex) => Console.WriteLine($"Error: {ex.Message}\nStack Trace:\n{ex.StackTrace}");

    /*
    Method: IsSelectionWithinLimit
    Purpose: Validates that the number of selected items in a CheckedListBox does not exceed a maximum limit.

    Parameters:
    - CheckedListBox clb: The CheckedListBox control to check.
    - int maxSelections: The maximum allowable number of selected items.

    Returns:
    - bool: True if the number of selections is within the limit; otherwise, false.
    */
    public static bool IsSelectionWithinLimit(CheckedListBox clb, int maxSelections) => clb.CheckedItems.Count <= maxSelections;

    /*
    Method: UpdateSelectionLimit
    Purpose: Enforces a selection limit in a CheckedListBox.

    Parameters:
    - CheckedListBox clb: The CheckedListBox control to check.
    - int maxSelections: The maximum allowable number of selected items.
    - ItemCheckEventArgs e: Event arguments including the item's check state.

    Returns:
    - void
    */
    public static void UpdateSelectionLimit(CheckedListBox clb, int maxSelections, ItemCheckEventArgs e)
    {
        if (e.NewValue == CheckState.Checked && clb.CheckedItems.Count >= maxSelections)
        {
            e.NewValue = CheckState.Unchecked;
            MessageBox.Show($"You can only select up to {maxSelections} options.", "Selection Limit", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    /*
    Method: SaveCheckBoxStates
    Purpose: Saves the checked states of items in a CheckedListBox to a dictionary.

    Parameters:
    - CheckedListBox clb: The CheckedListBox control.
    - string itemName: A prefix for each item's key in the dictionary.
    - Dictionary<string, bool> itemState: Dictionary to store the check states.

    Returns:
    - void
    */
    public static void SaveCheckBoxStates(CheckedListBox clb, string itemName, Dictionary<string, bool> itemState)
    {
        for (int i = 0; i < clb.Items.Count; i++)
        {
            string option = clb.Items[i].ToString();
            itemState[$"{itemName}_{option}"] = clb.GetItemChecked(i);
        }
    }

    /*
    Method: RestoreCheckBoxStates
    Purpose: Restores the checked states of items in a CheckedListBox from a dictionary.

    Parameters:
    - CheckedListBox clb: The CheckedListBox control.
    - string itemName: A prefix for each item's key in the dictionary.
    - Dictionary<string, bool> itemState: Dictionary containing the saved check states.

    Returns:
    - void
    */
    public static void RestoreCheckBoxStates(CheckedListBox clb, string itemName, Dictionary<string, bool> itemState)
    {
        for (int i = 0; i < clb.Items.Count; i++)
        {
            string option = clb.Items[i].ToString();
            clb.SetItemChecked(i, itemState.ContainsKey($"{itemName}_{option}") && itemState[$"{itemName}_{option}"]);
        }
    }

    /*
    Method: IsSelectionMade
    Purpose: Checks if a selection has been made in a control.

    Parameters:
    - int selectedIndex: The selected index of the control.

    Returns:
    - bool: True if a selection is made (index != -1); otherwise, false.
    */
    public static bool IsSelectionMade(int selectedIndex) => selectedIndex != -1;

    /*
    Method: IsTextPresent
    Purpose: Checks if a given text string is not null or empty.

    Parameters:
    - string text: The text string to validate.

    Returns:
    - bool: True if the text is not null or empty; otherwise, false.
    */
    public static bool IsTextPresent(string text) => !string.IsNullOrEmpty(text);

    /*
    Method: IsDecimal
    Purpose: Checks if a given string represents a valid decimal number.

    Parameters:
    - string value: The string to validate.

    Returns:
    - bool: True if the string is a valid decimal; otherwise, false.
    */
    public static bool IsDecimal(string value) => decimal.TryParse(value, out _);

    /*
    Method: IsInt32
    Purpose: Checks if a given string represents a valid Int32 integer.

    Parameters:
    - string value: The string to validate.

    Returns:
    - bool: True if the string is a valid Int32; otherwise, false.
    */
    public static bool IsInt32(string value) => int.TryParse(value, out _);

    /*
    Method: Swap
    Purpose: Swaps the values of two variables.

    Parameters:
    - ref T a: First variable.
    - ref T b: Second variable.

    Returns:
    - void
    */
    public static void Swap<T>(ref T a, ref T b)
    {
        T temp = a;
        a = b;
        b = temp;
    }
}
