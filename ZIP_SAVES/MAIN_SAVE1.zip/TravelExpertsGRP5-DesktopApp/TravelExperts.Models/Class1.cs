﻿namespace TravelExperts.Models
{
    public class Class1
    {

    }
}
